package com.Hostel.RoomAllocation;

import com.Hostel.RoomAllocation.controller.HostelController;

public class App {
    public static void main(String[] args) {
        new HostelController().start();
    }
}
