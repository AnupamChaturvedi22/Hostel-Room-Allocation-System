package com.Hostel.RoomAllocation.model;

import java.sql.Date;

public class Allocation {
    private int allocationId;
    private int studentId;
    private int roomId;
    private Date dateIn;
    private Date dateOut;
}
