package com.Hostel.RoomAllocation.DAO.impl;

import com.Hostel.RoomAllocation.DAO.RoomDAO;
import com.Hostel.RoomAllocation.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class RoomDAOImpl implements RoomDAO {

    public void addRoom(String number, String type, int capacity) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO rooms(room_number,type,capacity,occupied_beds) VALUES(?,?,?,0)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, number);
            ps.setString(2, type);
            ps.setInt(3, capacity);
            ps.executeUpdate();
            System.out.println("✅ Room Added");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	@Override
	public void getAllRooms() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateOccupiedBeds(int roomId, int beds) {
		// TODO Auto-generated method stub
		
	}
}
