package com.Hostel.RoomAllocation.model;

public class Room {
    private int roomId;
    private String roomNumber;
    private String type;
    private int capacity;
    private int occupiedBeds;
}
