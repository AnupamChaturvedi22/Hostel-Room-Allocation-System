package com.Hostel.RoomAllocation.model;

public class Student {
    private int studentId;
    private String name;
    private String course;
    private String phone;
    private String address;

    // getters & setters
}
