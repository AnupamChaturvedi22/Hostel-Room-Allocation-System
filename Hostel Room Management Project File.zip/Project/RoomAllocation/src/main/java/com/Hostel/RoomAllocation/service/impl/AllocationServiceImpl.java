package com.Hostel.RoomAllocation.service.impl;

import com.Hostel.RoomAllocation.DAO.AllocationDAO;
import com.Hostel.RoomAllocation.DAO.impl.AllocationDAOImpl;
import com.Hostel.RoomAllocation.service.AllocationService;

public class AllocationServiceImpl implements AllocationService {

    private AllocationDAO allocationDAO = new AllocationDAOImpl();

    @Override
    public void allocateRoom(int studentId, int roomId) {
        allocationDAO.allocateRoom(studentId, roomId);
    }

    @Override
    public void deallocateRoom(int allocationId) {
        allocationDAO.deallocateRoom(allocationId);
    }

    @Override
    public void viewAllocations() {
        allocationDAO.getAllAllocations();
    }
}
