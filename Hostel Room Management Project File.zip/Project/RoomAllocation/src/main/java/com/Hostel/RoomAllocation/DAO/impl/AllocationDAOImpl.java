package com.Hostel.RoomAllocation.DAO.impl;

import com.Hostel.RoomAllocation.DAO.AllocationDAO;
import com.Hostel.RoomAllocation.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;

public class AllocationDAOImpl implements AllocationDAO {

    public void allocateRoom(int studentId, int roomId) {
        try (Connection con = DBConnection.getConnection()) {

            String sql = "INSERT INTO allocations(student_id,room_id,date_in) VALUES(?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, studentId);
            ps.setInt(2, roomId);
            ps.setDate(3, new Date(System.currentTimeMillis()));
            ps.executeUpdate();

            System.out.println("✅ Room Allocated");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	@Override
	public void deallocateRoom(int allocationId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllAllocations() {
		// TODO Auto-generated method stub
		
	}
}
