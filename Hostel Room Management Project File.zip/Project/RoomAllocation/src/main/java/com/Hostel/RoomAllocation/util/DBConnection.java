package com.Hostel.RoomAllocation.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/hostel_db";
    private static final String USER = "root";
    private static final String PASSWORD = "sql@2292#";

    private static Connection connection;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            createTables();   // 👈 IMPORTANT

            System.out.println("✅ Database connected & tables ready");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        return connection;
    }

    private static void createTables() {
        try (Statement st = connection.createStatement()) {

            // STUDENTS
            st.execute("""
                CREATE TABLE IF NOT EXISTS students (
                    student_id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(100),
                    course VARCHAR(100),
                    phone VARCHAR(20),
                    address VARCHAR(255)
                )
            """);

            // ROOMS
            st.execute("""
                CREATE TABLE IF NOT EXISTS rooms (
                    room_id INT PRIMARY KEY AUTO_INCREMENT,
                    room_number VARCHAR(20),
                    type VARCHAR(50),
                    capacity INT,
                    occupied_beds INT DEFAULT 0
                )
            """);

            // ALLOCATIONS
            st.execute("""
                CREATE TABLE IF NOT EXISTS allocations (
                    allocation_id INT PRIMARY KEY AUTO_INCREMENT,
                    student_id INT UNIQUE,
                    room_id INT,
                    date_in DATE,
                    date_out DATE,
                    FOREIGN KEY (student_id) REFERENCES students(student_id),
                    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
                )
            """);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
