package com.Hostel.RoomAllocation.service.impl;

import com.Hostel.RoomAllocation.DAO.RoomDAO;
import com.Hostel.RoomAllocation.DAO.impl.RoomDAOImpl;
import com.Hostel.RoomAllocation.service.RoomService;

public class RoomServiceImpl implements RoomService {

    private RoomDAO roomDAO = new RoomDAOImpl();

    @Override
    public void addRoom(String roomNumber, String type, int capacity) {
        roomDAO.addRoom(roomNumber, type, capacity);
    }

    @Override
    public void viewRooms() {
        roomDAO.getAllRooms();
    }

    @Override
    public void updateOccupiedBeds(int roomId, int beds) {
        roomDAO.updateOccupiedBeds(roomId, beds);
    }
}
