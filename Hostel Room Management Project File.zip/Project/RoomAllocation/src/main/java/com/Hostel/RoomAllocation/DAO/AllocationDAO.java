package com.Hostel.RoomAllocation.DAO;

public interface AllocationDAO {
    void allocateRoom(int studentId, int roomId);

	void deallocateRoom(int allocationId);

	void getAllAllocations();
}
