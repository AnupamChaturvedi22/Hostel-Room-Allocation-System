package com.Hostel.RoomAllocation.service;

public interface AllocationService {

    void allocateRoom(int studentId, int roomId);

    void deallocateRoom(int allocationId);

    void viewAllocations();
}
