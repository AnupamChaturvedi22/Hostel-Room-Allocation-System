package com.Hostel.RoomAllocation.DAO;

public interface StudentDAO {
    void addStudent(String name, String course, String phone, String address);

	void updateStudent(int studentId, String phone, String address);

	void getAllStudents();
}
