package com.Hostel.RoomAllocation.controller;

import com.Hostel.RoomAllocation.service.RoomService;
import com.Hostel.RoomAllocation.service.impl.RoomServiceImpl;

import java.util.Scanner;

public class RoomController {

    private RoomService roomService = new RoomServiceImpl();
    private Scanner sc = new Scanner(System.in);

    public void roomMenu() {

        System.out.println("\n--- Room Management ---");
        System.out.println("1. Add Room");
        System.out.println("0. Back");

        int choice = sc.nextInt();
        sc.nextLine();

        if (choice == 1) {
            System.out.print("Enter Room Number: ");
            String roomNumber = sc.nextLine();

            System.out.print("Enter Room Type (Single/Double): ");
            String type = sc.nextLine();

            System.out.print("Enter Capacity: ");
            int capacity = sc.nextInt();

            roomService.addRoom(roomNumber, type, capacity);
        }
    }
}
