package com.Hostel.RoomAllocation.service.impl;

import com.Hostel.RoomAllocation.DAO.StudentDAO;
import com.Hostel.RoomAllocation.DAO.impl.StudentDAOImpl;
import com.Hostel.RoomAllocation.service.StudentService;

public class StudentServiceImpl implements StudentService {

    private StudentDAO studentDAO = new StudentDAOImpl();

    @Override
    public void registerStudent(String name, String course, String phone, String address) {
        studentDAO.addStudent(name, course, phone, address);
    }

    @Override
    public void updateStudent(int studentId, String phone, String address) {
        studentDAO.updateStudent(studentId, phone, address);
    }

    @Override
    public void viewStudents() {
        studentDAO.getAllStudents();
    }
}
