package com.Hostel.RoomAllocation.controller;

import com.Hostel.RoomAllocation.service.AllocationService;
import com.Hostel.RoomAllocation.service.impl.AllocationServiceImpl;

import java.util.Scanner;

public class AllocationController {

    private AllocationService allocationService = new AllocationServiceImpl();
    private Scanner sc = new Scanner(System.in);

    public void allocationMenu() {

        System.out.println("\n--- Room Allocation ---");
        System.out.println("1. Allocate Room");
        System.out.println("0. Back");

        int choice = sc.nextInt();

        if (choice == 1) {
            System.out.print("Enter Student ID: ");
            int studentId = sc.nextInt();

            System.out.print("Enter Room ID: ");
            int roomId = sc.nextInt();

            allocationService.allocateRoom(studentId, roomId);
        }
    }
}
