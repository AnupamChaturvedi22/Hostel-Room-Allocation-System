package com.Hostel.RoomAllocation.DAO.impl;

import com.Hostel.RoomAllocation.DAO.StudentDAO;
import com.Hostel.RoomAllocation.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class StudentDAOImpl implements StudentDAO {

    public void addStudent(String name, String course, String phone, String address) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO students(name,course,phone,address) VALUES(?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, course);
            ps.setString(3, phone);
            ps.setString(4, address);
            ps.executeUpdate();
            System.out.println("✅ Student Registered");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	@Override
	public void updateStudent(int studentId, String phone, String address) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAllStudents() {
		// TODO Auto-generated method stub
		
	}
}
