package com.Hostel.RoomAllocation.service;

public interface RoomService {

    void addRoom(String roomNumber, String type, int capacity);

    void viewRooms();

    void updateOccupiedBeds(int roomId, int beds);
}
