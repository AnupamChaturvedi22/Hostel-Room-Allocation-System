package com.Hostel.RoomAllocation.controller;

import com.Hostel.RoomAllocation.service.StudentService;
import com.Hostel.RoomAllocation.service.impl.StudentServiceImpl;

import java.util.Scanner;

public class StudentController {

    private StudentService studentService = new StudentServiceImpl();
    private Scanner sc = new Scanner(System.in);

    public void studentMenu() {

        System.out.println("\n--- Student Management ---");
        System.out.println("1. Register Student");
        System.out.println("0. Back");

        int choice = sc.nextInt();
        sc.nextLine();

        if (choice == 1) {
            System.out.print("Enter Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Course: ");
            String course = sc.nextLine();

            System.out.print("Enter Phone: ");
            String phone = sc.nextLine();

            System.out.print("Enter Address: ");
            String address = sc.nextLine();

            studentService.registerStudent(name, course, phone, address);
        }
    }
}
