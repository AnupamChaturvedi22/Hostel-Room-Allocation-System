package com.Hostel.RoomAllocation.DAO;

public interface RoomDAO {
    void addRoom(String number, String type, int capacity);

	void getAllRooms();

	void updateOccupiedBeds(int roomId, int beds);
}
