package com.Hostel.RoomAllocation.service;

public interface StudentService {

    void registerStudent(String name, String course, String phone, String address);

    void updateStudent(int studentId, String phone, String address);

    void viewStudents();
}
