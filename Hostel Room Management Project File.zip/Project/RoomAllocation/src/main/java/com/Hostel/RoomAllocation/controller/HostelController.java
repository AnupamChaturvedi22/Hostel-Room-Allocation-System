package com.Hostel.RoomAllocation.controller;

import java.util.Scanner;

public class HostelController {

    public void start() {

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n==== HOSTEL ROOM ALLOCATION SYSTEM ====");
            System.out.println("1. Student Module");
            System.out.println("2. Room Module");
            System.out.println("3. Allocation Module");
            System.out.println("0. Exit");

            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> new StudentController().studentMenu();
                case 2 -> new RoomController().roomMenu();
                case 3 -> new AllocationController().allocationMenu();
                case 0 -> {
                    System.out.println("Thank you!");
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }
}
